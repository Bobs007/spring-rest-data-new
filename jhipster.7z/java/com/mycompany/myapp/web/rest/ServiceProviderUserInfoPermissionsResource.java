package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.domain.ServiceProviderUserInfoPermissions;
import com.mycompany.myapp.repository.ServiceProviderUserInfoPermissionsRepository;
import com.mycompany.myapp.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.mycompany.myapp.domain.ServiceProviderUserInfoPermissions}.
 */
@RestController
@RequestMapping("/api")
@Transactional
public class ServiceProviderUserInfoPermissionsResource {

    private final Logger log = LoggerFactory.getLogger(ServiceProviderUserInfoPermissionsResource.class);

    private static final String ENTITY_NAME = "serviceProviderUserInfoPermissions";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final ServiceProviderUserInfoPermissionsRepository serviceProviderUserInfoPermissionsRepository;

    public ServiceProviderUserInfoPermissionsResource(ServiceProviderUserInfoPermissionsRepository serviceProviderUserInfoPermissionsRepository) {
        this.serviceProviderUserInfoPermissionsRepository = serviceProviderUserInfoPermissionsRepository;
    }

    /**
     * {@code POST  /service-provider-user-info-permissions} : Create a new serviceProviderUserInfoPermissions.
     *
     * @param serviceProviderUserInfoPermissions the serviceProviderUserInfoPermissions to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new serviceProviderUserInfoPermissions, or with status {@code 400 (Bad Request)} if the serviceProviderUserInfoPermissions has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/service-provider-user-info-permissions")
    public ResponseEntity<ServiceProviderUserInfoPermissions> createServiceProviderUserInfoPermissions(@RequestBody ServiceProviderUserInfoPermissions serviceProviderUserInfoPermissions) throws URISyntaxException {
        log.debug("REST request to save ServiceProviderUserInfoPermissions : {}", serviceProviderUserInfoPermissions);
        if (serviceProviderUserInfoPermissions.getId() != null) {
            throw new BadRequestAlertException("A new serviceProviderUserInfoPermissions cannot already have an ID", ENTITY_NAME, "idexists");
        }
        ServiceProviderUserInfoPermissions result = serviceProviderUserInfoPermissionsRepository.save(serviceProviderUserInfoPermissions);
        return ResponseEntity.created(new URI("/api/service-provider-user-info-permissions/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /service-provider-user-info-permissions} : Updates an existing serviceProviderUserInfoPermissions.
     *
     * @param serviceProviderUserInfoPermissions the serviceProviderUserInfoPermissions to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated serviceProviderUserInfoPermissions,
     * or with status {@code 400 (Bad Request)} if the serviceProviderUserInfoPermissions is not valid,
     * or with status {@code 500 (Internal Server Error)} if the serviceProviderUserInfoPermissions couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/service-provider-user-info-permissions")
    public ResponseEntity<ServiceProviderUserInfoPermissions> updateServiceProviderUserInfoPermissions(@RequestBody ServiceProviderUserInfoPermissions serviceProviderUserInfoPermissions) throws URISyntaxException {
        log.debug("REST request to update ServiceProviderUserInfoPermissions : {}", serviceProviderUserInfoPermissions);
        if (serviceProviderUserInfoPermissions.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        ServiceProviderUserInfoPermissions result = serviceProviderUserInfoPermissionsRepository.save(serviceProviderUserInfoPermissions);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, serviceProviderUserInfoPermissions.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /service-provider-user-info-permissions} : get all the serviceProviderUserInfoPermissions.
     *
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of serviceProviderUserInfoPermissions in body.
     */
    @GetMapping("/service-provider-user-info-permissions")
    public List<ServiceProviderUserInfoPermissions> getAllServiceProviderUserInfoPermissions() {
        log.debug("REST request to get all ServiceProviderUserInfoPermissions");
        return serviceProviderUserInfoPermissionsRepository.findAll();
    }

    /**
     * {@code GET  /service-provider-user-info-permissions/:id} : get the "id" serviceProviderUserInfoPermissions.
     *
     * @param id the id of the serviceProviderUserInfoPermissions to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the serviceProviderUserInfoPermissions, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/service-provider-user-info-permissions/{id}")
    public ResponseEntity<ServiceProviderUserInfoPermissions> getServiceProviderUserInfoPermissions(@PathVariable Long id) {
        log.debug("REST request to get ServiceProviderUserInfoPermissions : {}", id);
        Optional<ServiceProviderUserInfoPermissions> serviceProviderUserInfoPermissions = serviceProviderUserInfoPermissionsRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(serviceProviderUserInfoPermissions);
    }

    /**
     * {@code DELETE  /service-provider-user-info-permissions/:id} : delete the "id" serviceProviderUserInfoPermissions.
     *
     * @param id the id of the serviceProviderUserInfoPermissions to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/service-provider-user-info-permissions/{id}")
    public ResponseEntity<Void> deleteServiceProviderUserInfoPermissions(@PathVariable Long id) {
        log.debug("REST request to delete ServiceProviderUserInfoPermissions : {}", id);
        serviceProviderUserInfoPermissionsRepository.deleteById(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString())).build();
    }
}
