package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.domain.ServiceProviderComments;
import com.mycompany.myapp.repository.ServiceProviderCommentsRepository;
import com.mycompany.myapp.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.mycompany.myapp.domain.ServiceProviderComments}.
 */
@RestController
@RequestMapping("/api")
@Transactional
public class ServiceProviderCommentsResource {

    private final Logger log = LoggerFactory.getLogger(ServiceProviderCommentsResource.class);

    private static final String ENTITY_NAME = "serviceProviderComments";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final ServiceProviderCommentsRepository serviceProviderCommentsRepository;

    public ServiceProviderCommentsResource(ServiceProviderCommentsRepository serviceProviderCommentsRepository) {
        this.serviceProviderCommentsRepository = serviceProviderCommentsRepository;
    }

    /**
     * {@code POST  /service-provider-comments} : Create a new serviceProviderComments.
     *
     * @param serviceProviderComments the serviceProviderComments to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new serviceProviderComments, or with status {@code 400 (Bad Request)} if the serviceProviderComments has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/service-provider-comments")
    public ResponseEntity<ServiceProviderComments> createServiceProviderComments(@RequestBody ServiceProviderComments serviceProviderComments) throws URISyntaxException {
        log.debug("REST request to save ServiceProviderComments : {}", serviceProviderComments);
        if (serviceProviderComments.getId() != null) {
            throw new BadRequestAlertException("A new serviceProviderComments cannot already have an ID", ENTITY_NAME, "idexists");
        }
        ServiceProviderComments result = serviceProviderCommentsRepository.save(serviceProviderComments);
        return ResponseEntity.created(new URI("/api/service-provider-comments/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /service-provider-comments} : Updates an existing serviceProviderComments.
     *
     * @param serviceProviderComments the serviceProviderComments to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated serviceProviderComments,
     * or with status {@code 400 (Bad Request)} if the serviceProviderComments is not valid,
     * or with status {@code 500 (Internal Server Error)} if the serviceProviderComments couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/service-provider-comments")
    public ResponseEntity<ServiceProviderComments> updateServiceProviderComments(@RequestBody ServiceProviderComments serviceProviderComments) throws URISyntaxException {
        log.debug("REST request to update ServiceProviderComments : {}", serviceProviderComments);
        if (serviceProviderComments.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        ServiceProviderComments result = serviceProviderCommentsRepository.save(serviceProviderComments);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, serviceProviderComments.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /service-provider-comments} : get all the serviceProviderComments.
     *
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of serviceProviderComments in body.
     */
    @GetMapping("/service-provider-comments")
    public List<ServiceProviderComments> getAllServiceProviderComments() {
        log.debug("REST request to get all ServiceProviderComments");
        return serviceProviderCommentsRepository.findAll();
    }

    /**
     * {@code GET  /service-provider-comments/:id} : get the "id" serviceProviderComments.
     *
     * @param id the id of the serviceProviderComments to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the serviceProviderComments, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/service-provider-comments/{id}")
    public ResponseEntity<ServiceProviderComments> getServiceProviderComments(@PathVariable Long id) {
        log.debug("REST request to get ServiceProviderComments : {}", id);
        Optional<ServiceProviderComments> serviceProviderComments = serviceProviderCommentsRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(serviceProviderComments);
    }

    /**
     * {@code DELETE  /service-provider-comments/:id} : delete the "id" serviceProviderComments.
     *
     * @param id the id of the serviceProviderComments to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/service-provider-comments/{id}")
    public ResponseEntity<Void> deleteServiceProviderComments(@PathVariable Long id) {
        log.debug("REST request to delete ServiceProviderComments : {}", id);
        serviceProviderCommentsRepository.deleteById(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString())).build();
    }
}
