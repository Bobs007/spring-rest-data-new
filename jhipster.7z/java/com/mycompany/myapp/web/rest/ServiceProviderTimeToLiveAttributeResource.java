package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.domain.ServiceProviderTimeToLiveAttribute;
import com.mycompany.myapp.repository.ServiceProviderTimeToLiveAttributeRepository;
import com.mycompany.myapp.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.mycompany.myapp.domain.ServiceProviderTimeToLiveAttribute}.
 */
@RestController
@RequestMapping("/api")
@Transactional
public class ServiceProviderTimeToLiveAttributeResource {

    private final Logger log = LoggerFactory.getLogger(ServiceProviderTimeToLiveAttributeResource.class);

    private static final String ENTITY_NAME = "serviceProviderTimeToLiveAttribute";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final ServiceProviderTimeToLiveAttributeRepository serviceProviderTimeToLiveAttributeRepository;

    public ServiceProviderTimeToLiveAttributeResource(ServiceProviderTimeToLiveAttributeRepository serviceProviderTimeToLiveAttributeRepository) {
        this.serviceProviderTimeToLiveAttributeRepository = serviceProviderTimeToLiveAttributeRepository;
    }

    /**
     * {@code POST  /service-provider-time-to-live-attributes} : Create a new serviceProviderTimeToLiveAttribute.
     *
     * @param serviceProviderTimeToLiveAttribute the serviceProviderTimeToLiveAttribute to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new serviceProviderTimeToLiveAttribute, or with status {@code 400 (Bad Request)} if the serviceProviderTimeToLiveAttribute has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/service-provider-time-to-live-attributes")
    public ResponseEntity<ServiceProviderTimeToLiveAttribute> createServiceProviderTimeToLiveAttribute(@RequestBody ServiceProviderTimeToLiveAttribute serviceProviderTimeToLiveAttribute) throws URISyntaxException {
        log.debug("REST request to save ServiceProviderTimeToLiveAttribute : {}", serviceProviderTimeToLiveAttribute);
        if (serviceProviderTimeToLiveAttribute.getId() != null) {
            throw new BadRequestAlertException("A new serviceProviderTimeToLiveAttribute cannot already have an ID", ENTITY_NAME, "idexists");
        }
        ServiceProviderTimeToLiveAttribute result = serviceProviderTimeToLiveAttributeRepository.save(serviceProviderTimeToLiveAttribute);
        return ResponseEntity.created(new URI("/api/service-provider-time-to-live-attributes/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /service-provider-time-to-live-attributes} : Updates an existing serviceProviderTimeToLiveAttribute.
     *
     * @param serviceProviderTimeToLiveAttribute the serviceProviderTimeToLiveAttribute to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated serviceProviderTimeToLiveAttribute,
     * or with status {@code 400 (Bad Request)} if the serviceProviderTimeToLiveAttribute is not valid,
     * or with status {@code 500 (Internal Server Error)} if the serviceProviderTimeToLiveAttribute couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/service-provider-time-to-live-attributes")
    public ResponseEntity<ServiceProviderTimeToLiveAttribute> updateServiceProviderTimeToLiveAttribute(@RequestBody ServiceProviderTimeToLiveAttribute serviceProviderTimeToLiveAttribute) throws URISyntaxException {
        log.debug("REST request to update ServiceProviderTimeToLiveAttribute : {}", serviceProviderTimeToLiveAttribute);
        if (serviceProviderTimeToLiveAttribute.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        ServiceProviderTimeToLiveAttribute result = serviceProviderTimeToLiveAttributeRepository.save(serviceProviderTimeToLiveAttribute);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, serviceProviderTimeToLiveAttribute.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /service-provider-time-to-live-attributes} : get all the serviceProviderTimeToLiveAttributes.
     *
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of serviceProviderTimeToLiveAttributes in body.
     */
    @GetMapping("/service-provider-time-to-live-attributes")
    public List<ServiceProviderTimeToLiveAttribute> getAllServiceProviderTimeToLiveAttributes() {
        log.debug("REST request to get all ServiceProviderTimeToLiveAttributes");
        return serviceProviderTimeToLiveAttributeRepository.findAll();
    }

    /**
     * {@code GET  /service-provider-time-to-live-attributes/:id} : get the "id" serviceProviderTimeToLiveAttribute.
     *
     * @param id the id of the serviceProviderTimeToLiveAttribute to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the serviceProviderTimeToLiveAttribute, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/service-provider-time-to-live-attributes/{id}")
    public ResponseEntity<ServiceProviderTimeToLiveAttribute> getServiceProviderTimeToLiveAttribute(@PathVariable Long id) {
        log.debug("REST request to get ServiceProviderTimeToLiveAttribute : {}", id);
        Optional<ServiceProviderTimeToLiveAttribute> serviceProviderTimeToLiveAttribute = serviceProviderTimeToLiveAttributeRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(serviceProviderTimeToLiveAttribute);
    }

    /**
     * {@code DELETE  /service-provider-time-to-live-attributes/:id} : delete the "id" serviceProviderTimeToLiveAttribute.
     *
     * @param id the id of the serviceProviderTimeToLiveAttribute to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/service-provider-time-to-live-attributes/{id}")
    public ResponseEntity<Void> deleteServiceProviderTimeToLiveAttribute(@PathVariable Long id) {
        log.debug("REST request to delete ServiceProviderTimeToLiveAttribute : {}", id);
        serviceProviderTimeToLiveAttributeRepository.deleteById(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString())).build();
    }
}
