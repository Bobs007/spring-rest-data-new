package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.domain.ServiceProviderLoginScreenBranding;
import com.mycompany.myapp.repository.ServiceProviderLoginScreenBrandingRepository;
import com.mycompany.myapp.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.mycompany.myapp.domain.ServiceProviderLoginScreenBranding}.
 */
@RestController
@RequestMapping("/api")
@Transactional
public class ServiceProviderLoginScreenBrandingResource {

    private final Logger log = LoggerFactory.getLogger(ServiceProviderLoginScreenBrandingResource.class);

    private static final String ENTITY_NAME = "serviceProviderLoginScreenBranding";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final ServiceProviderLoginScreenBrandingRepository serviceProviderLoginScreenBrandingRepository;

    public ServiceProviderLoginScreenBrandingResource(ServiceProviderLoginScreenBrandingRepository serviceProviderLoginScreenBrandingRepository) {
        this.serviceProviderLoginScreenBrandingRepository = serviceProviderLoginScreenBrandingRepository;
    }

    /**
     * {@code POST  /service-provider-login-screen-brandings} : Create a new serviceProviderLoginScreenBranding.
     *
     * @param serviceProviderLoginScreenBranding the serviceProviderLoginScreenBranding to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new serviceProviderLoginScreenBranding, or with status {@code 400 (Bad Request)} if the serviceProviderLoginScreenBranding has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/service-provider-login-screen-brandings")
    public ResponseEntity<ServiceProviderLoginScreenBranding> createServiceProviderLoginScreenBranding(@RequestBody ServiceProviderLoginScreenBranding serviceProviderLoginScreenBranding) throws URISyntaxException {
        log.debug("REST request to save ServiceProviderLoginScreenBranding : {}", serviceProviderLoginScreenBranding);
        if (serviceProviderLoginScreenBranding.getId() != null) {
            throw new BadRequestAlertException("A new serviceProviderLoginScreenBranding cannot already have an ID", ENTITY_NAME, "idexists");
        }
        ServiceProviderLoginScreenBranding result = serviceProviderLoginScreenBrandingRepository.save(serviceProviderLoginScreenBranding);
        return ResponseEntity.created(new URI("/api/service-provider-login-screen-brandings/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /service-provider-login-screen-brandings} : Updates an existing serviceProviderLoginScreenBranding.
     *
     * @param serviceProviderLoginScreenBranding the serviceProviderLoginScreenBranding to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated serviceProviderLoginScreenBranding,
     * or with status {@code 400 (Bad Request)} if the serviceProviderLoginScreenBranding is not valid,
     * or with status {@code 500 (Internal Server Error)} if the serviceProviderLoginScreenBranding couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/service-provider-login-screen-brandings")
    public ResponseEntity<ServiceProviderLoginScreenBranding> updateServiceProviderLoginScreenBranding(@RequestBody ServiceProviderLoginScreenBranding serviceProviderLoginScreenBranding) throws URISyntaxException {
        log.debug("REST request to update ServiceProviderLoginScreenBranding : {}", serviceProviderLoginScreenBranding);
        if (serviceProviderLoginScreenBranding.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        ServiceProviderLoginScreenBranding result = serviceProviderLoginScreenBrandingRepository.save(serviceProviderLoginScreenBranding);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, serviceProviderLoginScreenBranding.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /service-provider-login-screen-brandings} : get all the serviceProviderLoginScreenBrandings.
     *
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of serviceProviderLoginScreenBrandings in body.
     */
    @GetMapping("/service-provider-login-screen-brandings")
    public List<ServiceProviderLoginScreenBranding> getAllServiceProviderLoginScreenBrandings() {
        log.debug("REST request to get all ServiceProviderLoginScreenBrandings");
        return serviceProviderLoginScreenBrandingRepository.findAll();
    }

    /**
     * {@code GET  /service-provider-login-screen-brandings/:id} : get the "id" serviceProviderLoginScreenBranding.
     *
     * @param id the id of the serviceProviderLoginScreenBranding to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the serviceProviderLoginScreenBranding, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/service-provider-login-screen-brandings/{id}")
    public ResponseEntity<ServiceProviderLoginScreenBranding> getServiceProviderLoginScreenBranding(@PathVariable Long id) {
        log.debug("REST request to get ServiceProviderLoginScreenBranding : {}", id);
        Optional<ServiceProviderLoginScreenBranding> serviceProviderLoginScreenBranding = serviceProviderLoginScreenBrandingRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(serviceProviderLoginScreenBranding);
    }

    /**
     * {@code DELETE  /service-provider-login-screen-brandings/:id} : delete the "id" serviceProviderLoginScreenBranding.
     *
     * @param id the id of the serviceProviderLoginScreenBranding to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/service-provider-login-screen-brandings/{id}")
    public ResponseEntity<Void> deleteServiceProviderLoginScreenBranding(@PathVariable Long id) {
        log.debug("REST request to delete ServiceProviderLoginScreenBranding : {}", id);
        serviceProviderLoginScreenBrandingRepository.deleteById(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString())).build();
    }
}
