package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.domain.ServiceProviderEmployeeAttribute;
import com.mycompany.myapp.repository.ServiceProviderEmployeeAttributeRepository;
import com.mycompany.myapp.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.mycompany.myapp.domain.ServiceProviderEmployeeAttribute}.
 */
@RestController
@RequestMapping("/api")
@Transactional
public class ServiceProviderEmployeeAttributeResource {

    private final Logger log = LoggerFactory.getLogger(ServiceProviderEmployeeAttributeResource.class);

    private static final String ENTITY_NAME = "serviceProviderEmployeeAttribute";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final ServiceProviderEmployeeAttributeRepository serviceProviderEmployeeAttributeRepository;

    public ServiceProviderEmployeeAttributeResource(ServiceProviderEmployeeAttributeRepository serviceProviderEmployeeAttributeRepository) {
        this.serviceProviderEmployeeAttributeRepository = serviceProviderEmployeeAttributeRepository;
    }

    /**
     * {@code POST  /service-provider-employee-attributes} : Create a new serviceProviderEmployeeAttribute.
     *
     * @param serviceProviderEmployeeAttribute the serviceProviderEmployeeAttribute to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new serviceProviderEmployeeAttribute, or with status {@code 400 (Bad Request)} if the serviceProviderEmployeeAttribute has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/service-provider-employee-attributes")
    public ResponseEntity<ServiceProviderEmployeeAttribute> createServiceProviderEmployeeAttribute(@RequestBody ServiceProviderEmployeeAttribute serviceProviderEmployeeAttribute) throws URISyntaxException {
        log.debug("REST request to save ServiceProviderEmployeeAttribute : {}", serviceProviderEmployeeAttribute);
        if (serviceProviderEmployeeAttribute.getId() != null) {
            throw new BadRequestAlertException("A new serviceProviderEmployeeAttribute cannot already have an ID", ENTITY_NAME, "idexists");
        }
        ServiceProviderEmployeeAttribute result = serviceProviderEmployeeAttributeRepository.save(serviceProviderEmployeeAttribute);
        return ResponseEntity.created(new URI("/api/service-provider-employee-attributes/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /service-provider-employee-attributes} : Updates an existing serviceProviderEmployeeAttribute.
     *
     * @param serviceProviderEmployeeAttribute the serviceProviderEmployeeAttribute to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated serviceProviderEmployeeAttribute,
     * or with status {@code 400 (Bad Request)} if the serviceProviderEmployeeAttribute is not valid,
     * or with status {@code 500 (Internal Server Error)} if the serviceProviderEmployeeAttribute couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/service-provider-employee-attributes")
    public ResponseEntity<ServiceProviderEmployeeAttribute> updateServiceProviderEmployeeAttribute(@RequestBody ServiceProviderEmployeeAttribute serviceProviderEmployeeAttribute) throws URISyntaxException {
        log.debug("REST request to update ServiceProviderEmployeeAttribute : {}", serviceProviderEmployeeAttribute);
        if (serviceProviderEmployeeAttribute.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        ServiceProviderEmployeeAttribute result = serviceProviderEmployeeAttributeRepository.save(serviceProviderEmployeeAttribute);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, serviceProviderEmployeeAttribute.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /service-provider-employee-attributes} : get all the serviceProviderEmployeeAttributes.
     *
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of serviceProviderEmployeeAttributes in body.
     */
    @GetMapping("/service-provider-employee-attributes")
    public List<ServiceProviderEmployeeAttribute> getAllServiceProviderEmployeeAttributes() {
        log.debug("REST request to get all ServiceProviderEmployeeAttributes");
        return serviceProviderEmployeeAttributeRepository.findAll();
    }

    /**
     * {@code GET  /service-provider-employee-attributes/:id} : get the "id" serviceProviderEmployeeAttribute.
     *
     * @param id the id of the serviceProviderEmployeeAttribute to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the serviceProviderEmployeeAttribute, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/service-provider-employee-attributes/{id}")
    public ResponseEntity<ServiceProviderEmployeeAttribute> getServiceProviderEmployeeAttribute(@PathVariable Long id) {
        log.debug("REST request to get ServiceProviderEmployeeAttribute : {}", id);
        Optional<ServiceProviderEmployeeAttribute> serviceProviderEmployeeAttribute = serviceProviderEmployeeAttributeRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(serviceProviderEmployeeAttribute);
    }

    /**
     * {@code DELETE  /service-provider-employee-attributes/:id} : delete the "id" serviceProviderEmployeeAttribute.
     *
     * @param id the id of the serviceProviderEmployeeAttribute to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/service-provider-employee-attributes/{id}")
    public ResponseEntity<Void> deleteServiceProviderEmployeeAttribute(@PathVariable Long id) {
        log.debug("REST request to delete ServiceProviderEmployeeAttribute : {}", id);
        serviceProviderEmployeeAttributeRepository.deleteById(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString())).build();
    }
}
