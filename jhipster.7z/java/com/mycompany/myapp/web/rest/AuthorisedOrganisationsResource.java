package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.domain.AuthorisedOrganisations;
import com.mycompany.myapp.repository.AuthorisedOrganisationsRepository;
import com.mycompany.myapp.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.mycompany.myapp.domain.AuthorisedOrganisations}.
 */
@RestController
@RequestMapping("/api")
@Transactional
public class AuthorisedOrganisationsResource {

    private final Logger log = LoggerFactory.getLogger(AuthorisedOrganisationsResource.class);

    private static final String ENTITY_NAME = "authorisedOrganisations";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final AuthorisedOrganisationsRepository authorisedOrganisationsRepository;

    public AuthorisedOrganisationsResource(AuthorisedOrganisationsRepository authorisedOrganisationsRepository) {
        this.authorisedOrganisationsRepository = authorisedOrganisationsRepository;
    }

    /**
     * {@code POST  /authorised-organisations} : Create a new authorisedOrganisations.
     *
     * @param authorisedOrganisations the authorisedOrganisations to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new authorisedOrganisations, or with status {@code 400 (Bad Request)} if the authorisedOrganisations has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/authorised-organisations")
    public ResponseEntity<AuthorisedOrganisations> createAuthorisedOrganisations(@RequestBody AuthorisedOrganisations authorisedOrganisations) throws URISyntaxException {
        log.debug("REST request to save AuthorisedOrganisations : {}", authorisedOrganisations);
        if (authorisedOrganisations.getId() != null) {
            throw new BadRequestAlertException("A new authorisedOrganisations cannot already have an ID", ENTITY_NAME, "idexists");
        }
        AuthorisedOrganisations result = authorisedOrganisationsRepository.save(authorisedOrganisations);
        return ResponseEntity.created(new URI("/api/authorised-organisations/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /authorised-organisations} : Updates an existing authorisedOrganisations.
     *
     * @param authorisedOrganisations the authorisedOrganisations to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated authorisedOrganisations,
     * or with status {@code 400 (Bad Request)} if the authorisedOrganisations is not valid,
     * or with status {@code 500 (Internal Server Error)} if the authorisedOrganisations couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/authorised-organisations")
    public ResponseEntity<AuthorisedOrganisations> updateAuthorisedOrganisations(@RequestBody AuthorisedOrganisations authorisedOrganisations) throws URISyntaxException {
        log.debug("REST request to update AuthorisedOrganisations : {}", authorisedOrganisations);
        if (authorisedOrganisations.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        AuthorisedOrganisations result = authorisedOrganisationsRepository.save(authorisedOrganisations);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, authorisedOrganisations.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /authorised-organisations} : get all the authorisedOrganisations.
     *
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of authorisedOrganisations in body.
     */
    @GetMapping("/authorised-organisations")
    public List<AuthorisedOrganisations> getAllAuthorisedOrganisations() {
        log.debug("REST request to get all AuthorisedOrganisations");
        return authorisedOrganisationsRepository.findAll();
    }

    /**
     * {@code GET  /authorised-organisations/:id} : get the "id" authorisedOrganisations.
     *
     * @param id the id of the authorisedOrganisations to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the authorisedOrganisations, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/authorised-organisations/{id}")
    public ResponseEntity<AuthorisedOrganisations> getAuthorisedOrganisations(@PathVariable Long id) {
        log.debug("REST request to get AuthorisedOrganisations : {}", id);
        Optional<AuthorisedOrganisations> authorisedOrganisations = authorisedOrganisationsRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(authorisedOrganisations);
    }

    /**
     * {@code DELETE  /authorised-organisations/:id} : delete the "id" authorisedOrganisations.
     *
     * @param id the id of the authorisedOrganisations to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/authorised-organisations/{id}")
    public ResponseEntity<Void> deleteAuthorisedOrganisations(@PathVariable Long id) {
        log.debug("REST request to delete AuthorisedOrganisations : {}", id);
        authorisedOrganisationsRepository.deleteById(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString())).build();
    }
}
