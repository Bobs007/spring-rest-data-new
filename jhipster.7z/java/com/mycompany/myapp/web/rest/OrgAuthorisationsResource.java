package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.domain.OrgAuthorisations;
import com.mycompany.myapp.repository.OrgAuthorisationsRepository;
import com.mycompany.myapp.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.mycompany.myapp.domain.OrgAuthorisations}.
 */
@RestController
@RequestMapping("/api")
@Transactional
public class OrgAuthorisationsResource {

    private final Logger log = LoggerFactory.getLogger(OrgAuthorisationsResource.class);

    private static final String ENTITY_NAME = "orgAuthorisations";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final OrgAuthorisationsRepository orgAuthorisationsRepository;

    public OrgAuthorisationsResource(OrgAuthorisationsRepository orgAuthorisationsRepository) {
        this.orgAuthorisationsRepository = orgAuthorisationsRepository;
    }

    /**
     * {@code POST  /org-authorisations} : Create a new orgAuthorisations.
     *
     * @param orgAuthorisations the orgAuthorisations to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new orgAuthorisations, or with status {@code 400 (Bad Request)} if the orgAuthorisations has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/org-authorisations")
    public ResponseEntity<OrgAuthorisations> createOrgAuthorisations(@RequestBody OrgAuthorisations orgAuthorisations) throws URISyntaxException {
        log.debug("REST request to save OrgAuthorisations : {}", orgAuthorisations);
        if (orgAuthorisations.getId() != null) {
            throw new BadRequestAlertException("A new orgAuthorisations cannot already have an ID", ENTITY_NAME, "idexists");
        }
        OrgAuthorisations result = orgAuthorisationsRepository.save(orgAuthorisations);
        return ResponseEntity.created(new URI("/api/org-authorisations/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /org-authorisations} : Updates an existing orgAuthorisations.
     *
     * @param orgAuthorisations the orgAuthorisations to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated orgAuthorisations,
     * or with status {@code 400 (Bad Request)} if the orgAuthorisations is not valid,
     * or with status {@code 500 (Internal Server Error)} if the orgAuthorisations couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/org-authorisations")
    public ResponseEntity<OrgAuthorisations> updateOrgAuthorisations(@RequestBody OrgAuthorisations orgAuthorisations) throws URISyntaxException {
        log.debug("REST request to update OrgAuthorisations : {}", orgAuthorisations);
        if (orgAuthorisations.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        OrgAuthorisations result = orgAuthorisationsRepository.save(orgAuthorisations);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, orgAuthorisations.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /org-authorisations} : get all the orgAuthorisations.
     *
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of orgAuthorisations in body.
     */
    @GetMapping("/org-authorisations")
    public List<OrgAuthorisations> getAllOrgAuthorisations() {
        log.debug("REST request to get all OrgAuthorisations");
        return orgAuthorisationsRepository.findAll();
    }

    /**
     * {@code GET  /org-authorisations/:id} : get the "id" orgAuthorisations.
     *
     * @param id the id of the orgAuthorisations to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the orgAuthorisations, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/org-authorisations/{id}")
    public ResponseEntity<OrgAuthorisations> getOrgAuthorisations(@PathVariable Long id) {
        log.debug("REST request to get OrgAuthorisations : {}", id);
        Optional<OrgAuthorisations> orgAuthorisations = orgAuthorisationsRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(orgAuthorisations);
    }

    /**
     * {@code DELETE  /org-authorisations/:id} : delete the "id" orgAuthorisations.
     *
     * @param id the id of the orgAuthorisations to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/org-authorisations/{id}")
    public ResponseEntity<Void> deleteOrgAuthorisations(@PathVariable Long id) {
        log.debug("REST request to delete OrgAuthorisations : {}", id);
        orgAuthorisationsRepository.deleteById(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString())).build();
    }
}
