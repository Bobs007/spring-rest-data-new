package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.domain.ServiceProviderOrgLinkAuthorisationAttributes;
import com.mycompany.myapp.repository.ServiceProviderOrgLinkAuthorisationAttributesRepository;
import com.mycompany.myapp.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.mycompany.myapp.domain.ServiceProviderOrgLinkAuthorisationAttributes}.
 */
@RestController
@RequestMapping("/api")
@Transactional
public class ServiceProviderOrgLinkAuthorisationAttributesResource {

    private final Logger log = LoggerFactory.getLogger(ServiceProviderOrgLinkAuthorisationAttributesResource.class);

    private static final String ENTITY_NAME = "serviceProviderOrgLinkAuthorisationAttributes";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final ServiceProviderOrgLinkAuthorisationAttributesRepository serviceProviderOrgLinkAuthorisationAttributesRepository;

    public ServiceProviderOrgLinkAuthorisationAttributesResource(ServiceProviderOrgLinkAuthorisationAttributesRepository serviceProviderOrgLinkAuthorisationAttributesRepository) {
        this.serviceProviderOrgLinkAuthorisationAttributesRepository = serviceProviderOrgLinkAuthorisationAttributesRepository;
    }

    /**
     * {@code POST  /service-provider-org-link-authorisation-attributes} : Create a new serviceProviderOrgLinkAuthorisationAttributes.
     *
     * @param serviceProviderOrgLinkAuthorisationAttributes the serviceProviderOrgLinkAuthorisationAttributes to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new serviceProviderOrgLinkAuthorisationAttributes, or with status {@code 400 (Bad Request)} if the serviceProviderOrgLinkAuthorisationAttributes has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/service-provider-org-link-authorisation-attributes")
    public ResponseEntity<ServiceProviderOrgLinkAuthorisationAttributes> createServiceProviderOrgLinkAuthorisationAttributes(@RequestBody ServiceProviderOrgLinkAuthorisationAttributes serviceProviderOrgLinkAuthorisationAttributes) throws URISyntaxException {
        log.debug("REST request to save ServiceProviderOrgLinkAuthorisationAttributes : {}", serviceProviderOrgLinkAuthorisationAttributes);
        if (serviceProviderOrgLinkAuthorisationAttributes.getId() != null) {
            throw new BadRequestAlertException("A new serviceProviderOrgLinkAuthorisationAttributes cannot already have an ID", ENTITY_NAME, "idexists");
        }
        ServiceProviderOrgLinkAuthorisationAttributes result = serviceProviderOrgLinkAuthorisationAttributesRepository.save(serviceProviderOrgLinkAuthorisationAttributes);
        return ResponseEntity.created(new URI("/api/service-provider-org-link-authorisation-attributes/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /service-provider-org-link-authorisation-attributes} : Updates an existing serviceProviderOrgLinkAuthorisationAttributes.
     *
     * @param serviceProviderOrgLinkAuthorisationAttributes the serviceProviderOrgLinkAuthorisationAttributes to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated serviceProviderOrgLinkAuthorisationAttributes,
     * or with status {@code 400 (Bad Request)} if the serviceProviderOrgLinkAuthorisationAttributes is not valid,
     * or with status {@code 500 (Internal Server Error)} if the serviceProviderOrgLinkAuthorisationAttributes couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/service-provider-org-link-authorisation-attributes")
    public ResponseEntity<ServiceProviderOrgLinkAuthorisationAttributes> updateServiceProviderOrgLinkAuthorisationAttributes(@RequestBody ServiceProviderOrgLinkAuthorisationAttributes serviceProviderOrgLinkAuthorisationAttributes) throws URISyntaxException {
        log.debug("REST request to update ServiceProviderOrgLinkAuthorisationAttributes : {}", serviceProviderOrgLinkAuthorisationAttributes);
        if (serviceProviderOrgLinkAuthorisationAttributes.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        ServiceProviderOrgLinkAuthorisationAttributes result = serviceProviderOrgLinkAuthorisationAttributesRepository.save(serviceProviderOrgLinkAuthorisationAttributes);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, serviceProviderOrgLinkAuthorisationAttributes.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /service-provider-org-link-authorisation-attributes} : get all the serviceProviderOrgLinkAuthorisationAttributes.
     *
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of serviceProviderOrgLinkAuthorisationAttributes in body.
     */
    @GetMapping("/service-provider-org-link-authorisation-attributes")
    public List<ServiceProviderOrgLinkAuthorisationAttributes> getAllServiceProviderOrgLinkAuthorisationAttributes() {
        log.debug("REST request to get all ServiceProviderOrgLinkAuthorisationAttributes");
        return serviceProviderOrgLinkAuthorisationAttributesRepository.findAll();
    }

    /**
     * {@code GET  /service-provider-org-link-authorisation-attributes/:id} : get the "id" serviceProviderOrgLinkAuthorisationAttributes.
     *
     * @param id the id of the serviceProviderOrgLinkAuthorisationAttributes to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the serviceProviderOrgLinkAuthorisationAttributes, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/service-provider-org-link-authorisation-attributes/{id}")
    public ResponseEntity<ServiceProviderOrgLinkAuthorisationAttributes> getServiceProviderOrgLinkAuthorisationAttributes(@PathVariable Long id) {
        log.debug("REST request to get ServiceProviderOrgLinkAuthorisationAttributes : {}", id);
        Optional<ServiceProviderOrgLinkAuthorisationAttributes> serviceProviderOrgLinkAuthorisationAttributes = serviceProviderOrgLinkAuthorisationAttributesRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(serviceProviderOrgLinkAuthorisationAttributes);
    }

    /**
     * {@code DELETE  /service-provider-org-link-authorisation-attributes/:id} : delete the "id" serviceProviderOrgLinkAuthorisationAttributes.
     *
     * @param id the id of the serviceProviderOrgLinkAuthorisationAttributes to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/service-provider-org-link-authorisation-attributes/{id}")
    public ResponseEntity<Void> deleteServiceProviderOrgLinkAuthorisationAttributes(@PathVariable Long id) {
        log.debug("REST request to delete ServiceProviderOrgLinkAuthorisationAttributes : {}", id);
        serviceProviderOrgLinkAuthorisationAttributesRepository.deleteById(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString())).build();
    }
}
