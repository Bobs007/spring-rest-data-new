/**
 * Spring Security configuration.
 */
package com.mycompany.myapp.security;
