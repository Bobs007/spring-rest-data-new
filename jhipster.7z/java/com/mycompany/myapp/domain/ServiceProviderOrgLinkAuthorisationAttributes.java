package com.mycompany.myapp.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Objects;

import com.mycompany.myapp.domain.enumeration.OrgLinkingAuthzType;

/**
 * A ServiceProviderOrgLinkAuthorisationAttributes.
 */
@Entity
@Table(name = "service_provider_org_link_authorisation_attributes")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class ServiceProviderOrgLinkAuthorisationAttributes implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @Column(name = "org_link_allowed")
    private Boolean orgLinkAllowed;

    @Column(name = "org_link_parent_only")
    private Boolean orgLinkParentOnly;

    @Enumerated(EnumType.STRING)
    @Column(name = "org_link_authz_type")
    private OrgLinkingAuthzType orgLinkAuthzType;

    @Column(name = "org_link_authz_apiurl")
    private String orgLinkAuthzAPIURL;

    @Column(name = "org_link_redirect_url")
    private String orgLinkRedirectURL;

    @Column(name = "org_si_attribute_authz_apiurl")
    private String orgSIAttributeAuthzAPIURL;

    @Column(name = "org_link_authz_client_id")
    private String orgLinkAuthzClientId;

    @Column(name = "org_si_attribute_authz_client_id")
    private String orgSIAttributeAuthzClientId;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Boolean isOrgLinkAllowed() {
        return orgLinkAllowed;
    }

    public ServiceProviderOrgLinkAuthorisationAttributes orgLinkAllowed(Boolean orgLinkAllowed) {
        this.orgLinkAllowed = orgLinkAllowed;
        return this;
    }

    public void setOrgLinkAllowed(Boolean orgLinkAllowed) {
        this.orgLinkAllowed = orgLinkAllowed;
    }

    public Boolean isOrgLinkParentOnly() {
        return orgLinkParentOnly;
    }

    public ServiceProviderOrgLinkAuthorisationAttributes orgLinkParentOnly(Boolean orgLinkParentOnly) {
        this.orgLinkParentOnly = orgLinkParentOnly;
        return this;
    }

    public void setOrgLinkParentOnly(Boolean orgLinkParentOnly) {
        this.orgLinkParentOnly = orgLinkParentOnly;
    }

    public OrgLinkingAuthzType getOrgLinkAuthzType() {
        return orgLinkAuthzType;
    }

    public ServiceProviderOrgLinkAuthorisationAttributes orgLinkAuthzType(OrgLinkingAuthzType orgLinkAuthzType) {
        this.orgLinkAuthzType = orgLinkAuthzType;
        return this;
    }

    public void setOrgLinkAuthzType(OrgLinkingAuthzType orgLinkAuthzType) {
        this.orgLinkAuthzType = orgLinkAuthzType;
    }

    public String getOrgLinkAuthzAPIURL() {
        return orgLinkAuthzAPIURL;
    }

    public ServiceProviderOrgLinkAuthorisationAttributes orgLinkAuthzAPIURL(String orgLinkAuthzAPIURL) {
        this.orgLinkAuthzAPIURL = orgLinkAuthzAPIURL;
        return this;
    }

    public void setOrgLinkAuthzAPIURL(String orgLinkAuthzAPIURL) {
        this.orgLinkAuthzAPIURL = orgLinkAuthzAPIURL;
    }

    public String getOrgLinkRedirectURL() {
        return orgLinkRedirectURL;
    }

    public ServiceProviderOrgLinkAuthorisationAttributes orgLinkRedirectURL(String orgLinkRedirectURL) {
        this.orgLinkRedirectURL = orgLinkRedirectURL;
        return this;
    }

    public void setOrgLinkRedirectURL(String orgLinkRedirectURL) {
        this.orgLinkRedirectURL = orgLinkRedirectURL;
    }

    public String getOrgSIAttributeAuthzAPIURL() {
        return orgSIAttributeAuthzAPIURL;
    }

    public ServiceProviderOrgLinkAuthorisationAttributes orgSIAttributeAuthzAPIURL(String orgSIAttributeAuthzAPIURL) {
        this.orgSIAttributeAuthzAPIURL = orgSIAttributeAuthzAPIURL;
        return this;
    }

    public void setOrgSIAttributeAuthzAPIURL(String orgSIAttributeAuthzAPIURL) {
        this.orgSIAttributeAuthzAPIURL = orgSIAttributeAuthzAPIURL;
    }

    public String getOrgLinkAuthzClientId() {
        return orgLinkAuthzClientId;
    }

    public ServiceProviderOrgLinkAuthorisationAttributes orgLinkAuthzClientId(String orgLinkAuthzClientId) {
        this.orgLinkAuthzClientId = orgLinkAuthzClientId;
        return this;
    }

    public void setOrgLinkAuthzClientId(String orgLinkAuthzClientId) {
        this.orgLinkAuthzClientId = orgLinkAuthzClientId;
    }

    public String getOrgSIAttributeAuthzClientId() {
        return orgSIAttributeAuthzClientId;
    }

    public ServiceProviderOrgLinkAuthorisationAttributes orgSIAttributeAuthzClientId(String orgSIAttributeAuthzClientId) {
        this.orgSIAttributeAuthzClientId = orgSIAttributeAuthzClientId;
        return this;
    }

    public void setOrgSIAttributeAuthzClientId(String orgSIAttributeAuthzClientId) {
        this.orgSIAttributeAuthzClientId = orgSIAttributeAuthzClientId;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ServiceProviderOrgLinkAuthorisationAttributes)) {
            return false;
        }
        return id != null && id.equals(((ServiceProviderOrgLinkAuthorisationAttributes) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "ServiceProviderOrgLinkAuthorisationAttributes{" +
            "id=" + getId() +
            ", orgLinkAllowed='" + isOrgLinkAllowed() + "'" +
            ", orgLinkParentOnly='" + isOrgLinkParentOnly() + "'" +
            ", orgLinkAuthzType='" + getOrgLinkAuthzType() + "'" +
            ", orgLinkAuthzAPIURL='" + getOrgLinkAuthzAPIURL() + "'" +
            ", orgLinkRedirectURL='" + getOrgLinkRedirectURL() + "'" +
            ", orgSIAttributeAuthzAPIURL='" + getOrgSIAttributeAuthzAPIURL() + "'" +
            ", orgLinkAuthzClientId='" + getOrgLinkAuthzClientId() + "'" +
            ", orgSIAttributeAuthzClientId='" + getOrgSIAttributeAuthzClientId() + "'" +
            "}";
    }
}
