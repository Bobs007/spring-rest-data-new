package com.mycompany.myapp.domain.enumeration;

/**
 * The UserAuthorisationType enumeration.
 */
public enum UserAuthorisationType {
    INDIVIDUAL, ORG_EMPLOYEE, LINKED_ORG_EMPLOYEE
}
