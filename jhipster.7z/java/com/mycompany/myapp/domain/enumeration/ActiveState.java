package com.mycompany.myapp.domain.enumeration;

/**
 * The ActiveState enumeration.
 */
public enum ActiveState {
    ACTIVE, DISABLE, DELETE
}
