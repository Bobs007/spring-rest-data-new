package com.mycompany.myapp.domain.enumeration;

/**
 * The OrgLinkingAuthzType enumeration.
 */
public enum OrgLinkingAuthzType {
    REDIRECT, WEB_SERVICE
}
