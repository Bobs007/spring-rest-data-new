package com.mycompany.myapp.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Objects;

/**
 * A SoftwareInstanceTimeToLive.
 */
@Entity
@Table(name = "software_instance_time_to_live")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class SoftwareInstanceTimeToLive implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @Column(name = "time_to_live_id")
    private String timeToLiveId;

    @Column(name = "s_i_lock_threshold")
    private Integer sILockThreshold;

    @Column(name = "s_i_valid_days")
    private Integer sIValidDays;

    @Column(name = "s_i_valid_months")
    private Integer sIValidMonths;

    @Column(name = "s_ijwk_valid_days")
    private Integer sIJWKValidDays;

    @Column(name = "s_iotac_valid_days")
    private Integer sIOTACValidDays;

    @Column(name = "s_iotac_lock_threshold")
    private Integer sIOTACLockThreshold;

    @Column(name = "s_i_access_token_expiry")
    private Integer sIAccessTokenExpiry;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTimeToLiveId() {
        return timeToLiveId;
    }

    public SoftwareInstanceTimeToLive timeToLiveId(String timeToLiveId) {
        this.timeToLiveId = timeToLiveId;
        return this;
    }

    public void setTimeToLiveId(String timeToLiveId) {
        this.timeToLiveId = timeToLiveId;
    }

    public Integer getsILockThreshold() {
        return sILockThreshold;
    }

    public SoftwareInstanceTimeToLive sILockThreshold(Integer sILockThreshold) {
        this.sILockThreshold = sILockThreshold;
        return this;
    }

    public void setsILockThreshold(Integer sILockThreshold) {
        this.sILockThreshold = sILockThreshold;
    }

    public Integer getsIValidDays() {
        return sIValidDays;
    }

    public SoftwareInstanceTimeToLive sIValidDays(Integer sIValidDays) {
        this.sIValidDays = sIValidDays;
        return this;
    }

    public void setsIValidDays(Integer sIValidDays) {
        this.sIValidDays = sIValidDays;
    }

    public Integer getsIValidMonths() {
        return sIValidMonths;
    }

    public SoftwareInstanceTimeToLive sIValidMonths(Integer sIValidMonths) {
        this.sIValidMonths = sIValidMonths;
        return this;
    }

    public void setsIValidMonths(Integer sIValidMonths) {
        this.sIValidMonths = sIValidMonths;
    }

    public Integer getsIJWKValidDays() {
        return sIJWKValidDays;
    }

    public SoftwareInstanceTimeToLive sIJWKValidDays(Integer sIJWKValidDays) {
        this.sIJWKValidDays = sIJWKValidDays;
        return this;
    }

    public void setsIJWKValidDays(Integer sIJWKValidDays) {
        this.sIJWKValidDays = sIJWKValidDays;
    }

    public Integer getsIOTACValidDays() {
        return sIOTACValidDays;
    }

    public SoftwareInstanceTimeToLive sIOTACValidDays(Integer sIOTACValidDays) {
        this.sIOTACValidDays = sIOTACValidDays;
        return this;
    }

    public void setsIOTACValidDays(Integer sIOTACValidDays) {
        this.sIOTACValidDays = sIOTACValidDays;
    }

    public Integer getsIOTACLockThreshold() {
        return sIOTACLockThreshold;
    }

    public SoftwareInstanceTimeToLive sIOTACLockThreshold(Integer sIOTACLockThreshold) {
        this.sIOTACLockThreshold = sIOTACLockThreshold;
        return this;
    }

    public void setsIOTACLockThreshold(Integer sIOTACLockThreshold) {
        this.sIOTACLockThreshold = sIOTACLockThreshold;
    }

    public Integer getsIAccessTokenExpiry() {
        return sIAccessTokenExpiry;
    }

    public SoftwareInstanceTimeToLive sIAccessTokenExpiry(Integer sIAccessTokenExpiry) {
        this.sIAccessTokenExpiry = sIAccessTokenExpiry;
        return this;
    }

    public void setsIAccessTokenExpiry(Integer sIAccessTokenExpiry) {
        this.sIAccessTokenExpiry = sIAccessTokenExpiry;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof SoftwareInstanceTimeToLive)) {
            return false;
        }
        return id != null && id.equals(((SoftwareInstanceTimeToLive) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "SoftwareInstanceTimeToLive{" +
            "id=" + getId() +
            ", timeToLiveId='" + getTimeToLiveId() + "'" +
            ", sILockThreshold=" + getsILockThreshold() +
            ", sIValidDays=" + getsIValidDays() +
            ", sIValidMonths=" + getsIValidMonths() +
            ", sIJWKValidDays=" + getsIJWKValidDays() +
            ", sIOTACValidDays=" + getsIOTACValidDays() +
            ", sIOTACLockThreshold=" + getsIOTACLockThreshold() +
            ", sIAccessTokenExpiry=" + getsIAccessTokenExpiry() +
            "}";
    }
}
