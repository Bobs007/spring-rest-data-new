package com.mycompany.myapp.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.util.Objects;
import java.util.HashSet;
import java.util.Set;

import com.mycompany.myapp.domain.enumeration.ActiveState;

/**
 * A ServiceProvider.
 */
@Entity
@Table(name = "service_provider")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class ServiceProvider implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @NotNull
    @Column(name = "service_code_id", nullable = false)
    private String serviceCodeId;

    @Column(name = "parent_service_code")
    private String parentServiceCode;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "active_state", nullable = false)
    private ActiveState activeState;

    @Column(name = "client_id")
    private String clientId;

    @Column(name = "allow_create_org")
    private Boolean allowCreateOrg;

    @Column(name = "allow_create_si_for_org")
    private Boolean allowCreateSIForOrg;

    @Column(name = "b_2_b_audience_code")
    private String b2BAudienceCode;

    @OneToOne
    @JoinColumn(unique = true)
    private ServiceProviderTimeToLiveAttribute serviceCodeId;

    @OneToOne
    @JoinColumn(unique = true)
    private ServiceProviderSIAttribute serviceCodeId;

    @OneToOne
    @JoinColumn(unique = true)
    private ServiceProviderEmployeeAttribute serviceCodeId;

    @OneToOne
    @JoinColumn(unique = true)
    private ServiceProviderComments serviceCodeId;

    @OneToOne
    @JoinColumn(unique = true)
    private ServiceProviderDisplayParameters serviceCodeId;

    @OneToOne
    @JoinColumn(unique = true)
    private ServiceProviderUserInfoPermissions serviceCodeId;

    @OneToOne
    @JoinColumn(unique = true)
    private ServiceProviderLoginScreenBranding serviceCodeId;

    @OneToOne
    @JoinColumn(unique = true)
    private ServiceProviderOrgLinkAuthorisationAttributes serviceCodeId;

    @OneToOne
    @JoinColumn(unique = true)
    private AuthorisedOrganisations serviceCodeId;

    @OneToMany(mappedBy = "serviceProvider")
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<ServiceProviderComments> serviceProviderComments = new HashSet<>();

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getServiceCodeId() {
        return serviceCodeId;
    }

    public ServiceProvider serviceCodeId(String serviceCodeId) {
        this.serviceCodeId = serviceCodeId;
        return this;
    }

    public void setServiceCodeId(String serviceCodeId) {
        this.serviceCodeId = serviceCodeId;
    }

    public String getParentServiceCode() {
        return parentServiceCode;
    }

    public ServiceProvider parentServiceCode(String parentServiceCode) {
        this.parentServiceCode = parentServiceCode;
        return this;
    }

    public void setParentServiceCode(String parentServiceCode) {
        this.parentServiceCode = parentServiceCode;
    }

    public ActiveState getActiveState() {
        return activeState;
    }

    public ServiceProvider activeState(ActiveState activeState) {
        this.activeState = activeState;
        return this;
    }

    public void setActiveState(ActiveState activeState) {
        this.activeState = activeState;
    }

    public String getClientId() {
        return clientId;
    }

    public ServiceProvider clientId(String clientId) {
        this.clientId = clientId;
        return this;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public Boolean isAllowCreateOrg() {
        return allowCreateOrg;
    }

    public ServiceProvider allowCreateOrg(Boolean allowCreateOrg) {
        this.allowCreateOrg = allowCreateOrg;
        return this;
    }

    public void setAllowCreateOrg(Boolean allowCreateOrg) {
        this.allowCreateOrg = allowCreateOrg;
    }

    public Boolean isAllowCreateSIForOrg() {
        return allowCreateSIForOrg;
    }

    public ServiceProvider allowCreateSIForOrg(Boolean allowCreateSIForOrg) {
        this.allowCreateSIForOrg = allowCreateSIForOrg;
        return this;
    }

    public void setAllowCreateSIForOrg(Boolean allowCreateSIForOrg) {
        this.allowCreateSIForOrg = allowCreateSIForOrg;
    }

    public String getb2BAudienceCode() {
        return b2BAudienceCode;
    }

    public ServiceProvider b2BAudienceCode(String b2BAudienceCode) {
        this.b2BAudienceCode = b2BAudienceCode;
        return this;
    }

    public void setb2BAudienceCode(String b2BAudienceCode) {
        this.b2BAudienceCode = b2BAudienceCode;
    }

    public ServiceProviderTimeToLiveAttribute getServiceCodeId() {
        return serviceCodeId;
    }

    public ServiceProvider serviceCodeId(ServiceProviderTimeToLiveAttribute serviceProviderTimeToLiveAttribute) {
        this.serviceCodeId = serviceProviderTimeToLiveAttribute;
        return this;
    }

    public void setServiceCodeId(ServiceProviderTimeToLiveAttribute serviceProviderTimeToLiveAttribute) {
        this.serviceCodeId = serviceProviderTimeToLiveAttribute;
    }

    public ServiceProviderSIAttribute getServiceCodeId() {
        return serviceCodeId;
    }

    public ServiceProvider serviceCodeId(ServiceProviderSIAttribute serviceProviderSIAttribute) {
        this.serviceCodeId = serviceProviderSIAttribute;
        return this;
    }

    public void setServiceCodeId(ServiceProviderSIAttribute serviceProviderSIAttribute) {
        this.serviceCodeId = serviceProviderSIAttribute;
    }

    public ServiceProviderEmployeeAttribute getServiceCodeId() {
        return serviceCodeId;
    }

    public ServiceProvider serviceCodeId(ServiceProviderEmployeeAttribute serviceProviderEmployeeAttribute) {
        this.serviceCodeId = serviceProviderEmployeeAttribute;
        return this;
    }

    public void setServiceCodeId(ServiceProviderEmployeeAttribute serviceProviderEmployeeAttribute) {
        this.serviceCodeId = serviceProviderEmployeeAttribute;
    }

    public ServiceProviderComments getServiceCodeId() {
        return serviceCodeId;
    }

    public ServiceProvider serviceCodeId(ServiceProviderComments serviceProviderComments) {
        this.serviceCodeId = serviceProviderComments;
        return this;
    }

    public void setServiceCodeId(ServiceProviderComments serviceProviderComments) {
        this.serviceCodeId = serviceProviderComments;
    }

    public ServiceProviderDisplayParameters getServiceCodeId() {
        return serviceCodeId;
    }

    public ServiceProvider serviceCodeId(ServiceProviderDisplayParameters serviceProviderDisplayParameters) {
        this.serviceCodeId = serviceProviderDisplayParameters;
        return this;
    }

    public void setServiceCodeId(ServiceProviderDisplayParameters serviceProviderDisplayParameters) {
        this.serviceCodeId = serviceProviderDisplayParameters;
    }

    public ServiceProviderUserInfoPermissions getServiceCodeId() {
        return serviceCodeId;
    }

    public ServiceProvider serviceCodeId(ServiceProviderUserInfoPermissions serviceProviderUserInfoPermissions) {
        this.serviceCodeId = serviceProviderUserInfoPermissions;
        return this;
    }

    public void setServiceCodeId(ServiceProviderUserInfoPermissions serviceProviderUserInfoPermissions) {
        this.serviceCodeId = serviceProviderUserInfoPermissions;
    }

    public ServiceProviderLoginScreenBranding getServiceCodeId() {
        return serviceCodeId;
    }

    public ServiceProvider serviceCodeId(ServiceProviderLoginScreenBranding serviceProviderLoginScreenBranding) {
        this.serviceCodeId = serviceProviderLoginScreenBranding;
        return this;
    }

    public void setServiceCodeId(ServiceProviderLoginScreenBranding serviceProviderLoginScreenBranding) {
        this.serviceCodeId = serviceProviderLoginScreenBranding;
    }

    public ServiceProviderOrgLinkAuthorisationAttributes getServiceCodeId() {
        return serviceCodeId;
    }

    public ServiceProvider serviceCodeId(ServiceProviderOrgLinkAuthorisationAttributes serviceProviderOrgLinkAuthorisationAttributes) {
        this.serviceCodeId = serviceProviderOrgLinkAuthorisationAttributes;
        return this;
    }

    public void setServiceCodeId(ServiceProviderOrgLinkAuthorisationAttributes serviceProviderOrgLinkAuthorisationAttributes) {
        this.serviceCodeId = serviceProviderOrgLinkAuthorisationAttributes;
    }

    public AuthorisedOrganisations getServiceCodeId() {
        return serviceCodeId;
    }

    public ServiceProvider serviceCodeId(AuthorisedOrganisations authorisedOrganisations) {
        this.serviceCodeId = authorisedOrganisations;
        return this;
    }

    public void setServiceCodeId(AuthorisedOrganisations authorisedOrganisations) {
        this.serviceCodeId = authorisedOrganisations;
    }

    public Set<ServiceProviderComments> getServiceProviderComments() {
        return serviceProviderComments;
    }

    public ServiceProvider serviceProviderComments(Set<ServiceProviderComments> serviceProviderComments) {
        this.serviceProviderComments = serviceProviderComments;
        return this;
    }

    public ServiceProvider addServiceProviderComments(ServiceProviderComments serviceProviderComments) {
        this.serviceProviderComments.add(serviceProviderComments);
        serviceProviderComments.setServiceProvider(this);
        return this;
    }

    public ServiceProvider removeServiceProviderComments(ServiceProviderComments serviceProviderComments) {
        this.serviceProviderComments.remove(serviceProviderComments);
        serviceProviderComments.setServiceProvider(null);
        return this;
    }

    public void setServiceProviderComments(Set<ServiceProviderComments> serviceProviderComments) {
        this.serviceProviderComments = serviceProviderComments;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ServiceProvider)) {
            return false;
        }
        return id != null && id.equals(((ServiceProvider) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "ServiceProvider{" +
            "id=" + getId() +
            ", serviceCodeId='" + getServiceCodeId() + "'" +
            ", parentServiceCode='" + getParentServiceCode() + "'" +
            ", activeState='" + getActiveState() + "'" +
            ", clientId='" + getClientId() + "'" +
            ", allowCreateOrg='" + isAllowCreateOrg() + "'" +
            ", allowCreateSIForOrg='" + isAllowCreateSIForOrg() + "'" +
            ", b2BAudienceCode='" + getb2BAudienceCode() + "'" +
            "}";
    }
}
