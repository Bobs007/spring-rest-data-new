package com.mycompany.myapp.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.util.Objects;

/**
 * A ServiceProviderDisplayParameters.
 */
@Entity
@Table(name = "service_provider_display_parameters")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class ServiceProviderDisplayParameters implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @NotNull
    @Column(name = "display_name", nullable = false)
    private String displayName;

    @Column(name = "display_description")
    private String displayDescription;

    @Lob
    @Column(name = "display_tile_image")
    private byte[] displayTileImage;

    @Column(name = "display_tile_image_content_type")
    private String displayTileImageContentType;

    @Column(name = "display_tile_on_screen")
    private Boolean displayTileOnScreen;

    @Column(name = "display_tile_landing_url")
    private String displayTileLandingURL;

    @Column(name = "display_tile_image_type")
    private String displayTileImageType;

    @Column(name = "display_linked_org_above_line")
    private Boolean displayLinkedOrgAboveLine;

    @NotNull
    @Column(name = "display_service_code", nullable = false)
    private String displayServiceCode;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public ServiceProviderDisplayParameters displayName(String displayName) {
        this.displayName = displayName;
        return this;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayDescription() {
        return displayDescription;
    }

    public ServiceProviderDisplayParameters displayDescription(String displayDescription) {
        this.displayDescription = displayDescription;
        return this;
    }

    public void setDisplayDescription(String displayDescription) {
        this.displayDescription = displayDescription;
    }

    public byte[] getDisplayTileImage() {
        return displayTileImage;
    }

    public ServiceProviderDisplayParameters displayTileImage(byte[] displayTileImage) {
        this.displayTileImage = displayTileImage;
        return this;
    }

    public void setDisplayTileImage(byte[] displayTileImage) {
        this.displayTileImage = displayTileImage;
    }

    public String getDisplayTileImageContentType() {
        return displayTileImageContentType;
    }

    public ServiceProviderDisplayParameters displayTileImageContentType(String displayTileImageContentType) {
        this.displayTileImageContentType = displayTileImageContentType;
        return this;
    }

    public void setDisplayTileImageContentType(String displayTileImageContentType) {
        this.displayTileImageContentType = displayTileImageContentType;
    }

    public Boolean isDisplayTileOnScreen() {
        return displayTileOnScreen;
    }

    public ServiceProviderDisplayParameters displayTileOnScreen(Boolean displayTileOnScreen) {
        this.displayTileOnScreen = displayTileOnScreen;
        return this;
    }

    public void setDisplayTileOnScreen(Boolean displayTileOnScreen) {
        this.displayTileOnScreen = displayTileOnScreen;
    }

    public String getDisplayTileLandingURL() {
        return displayTileLandingURL;
    }

    public ServiceProviderDisplayParameters displayTileLandingURL(String displayTileLandingURL) {
        this.displayTileLandingURL = displayTileLandingURL;
        return this;
    }

    public void setDisplayTileLandingURL(String displayTileLandingURL) {
        this.displayTileLandingURL = displayTileLandingURL;
    }

    public String getDisplayTileImageType() {
        return displayTileImageType;
    }

    public ServiceProviderDisplayParameters displayTileImageType(String displayTileImageType) {
        this.displayTileImageType = displayTileImageType;
        return this;
    }

    public void setDisplayTileImageType(String displayTileImageType) {
        this.displayTileImageType = displayTileImageType;
    }

    public Boolean isDisplayLinkedOrgAboveLine() {
        return displayLinkedOrgAboveLine;
    }

    public ServiceProviderDisplayParameters displayLinkedOrgAboveLine(Boolean displayLinkedOrgAboveLine) {
        this.displayLinkedOrgAboveLine = displayLinkedOrgAboveLine;
        return this;
    }

    public void setDisplayLinkedOrgAboveLine(Boolean displayLinkedOrgAboveLine) {
        this.displayLinkedOrgAboveLine = displayLinkedOrgAboveLine;
    }

    public String getDisplayServiceCode() {
        return displayServiceCode;
    }

    public ServiceProviderDisplayParameters displayServiceCode(String displayServiceCode) {
        this.displayServiceCode = displayServiceCode;
        return this;
    }

    public void setDisplayServiceCode(String displayServiceCode) {
        this.displayServiceCode = displayServiceCode;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ServiceProviderDisplayParameters)) {
            return false;
        }
        return id != null && id.equals(((ServiceProviderDisplayParameters) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "ServiceProviderDisplayParameters{" +
            "id=" + getId() +
            ", displayName='" + getDisplayName() + "'" +
            ", displayDescription='" + getDisplayDescription() + "'" +
            ", displayTileImage='" + getDisplayTileImage() + "'" +
            ", displayTileImageContentType='" + getDisplayTileImageContentType() + "'" +
            ", displayTileOnScreen='" + isDisplayTileOnScreen() + "'" +
            ", displayTileLandingURL='" + getDisplayTileLandingURL() + "'" +
            ", displayTileImageType='" + getDisplayTileImageType() + "'" +
            ", displayLinkedOrgAboveLine='" + isDisplayLinkedOrgAboveLine() + "'" +
            ", displayServiceCode='" + getDisplayServiceCode() + "'" +
            "}";
    }
}
