package com.mycompany.myapp.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Objects;

/**
 * A ServiceProviderLoginScreenBranding.
 */
@Entity
@Table(name = "service_provider_login_screen_branding")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class ServiceProviderLoginScreenBranding implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @Column(name = "branding_logo")
    private String brandingLogo;

    @Column(name = "branding_style_sheet")
    private String brandingStyleSheet;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBrandingLogo() {
        return brandingLogo;
    }

    public ServiceProviderLoginScreenBranding brandingLogo(String brandingLogo) {
        this.brandingLogo = brandingLogo;
        return this;
    }

    public void setBrandingLogo(String brandingLogo) {
        this.brandingLogo = brandingLogo;
    }

    public String getBrandingStyleSheet() {
        return brandingStyleSheet;
    }

    public ServiceProviderLoginScreenBranding brandingStyleSheet(String brandingStyleSheet) {
        this.brandingStyleSheet = brandingStyleSheet;
        return this;
    }

    public void setBrandingStyleSheet(String brandingStyleSheet) {
        this.brandingStyleSheet = brandingStyleSheet;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ServiceProviderLoginScreenBranding)) {
            return false;
        }
        return id != null && id.equals(((ServiceProviderLoginScreenBranding) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "ServiceProviderLoginScreenBranding{" +
            "id=" + getId() +
            ", brandingLogo='" + getBrandingLogo() + "'" +
            ", brandingStyleSheet='" + getBrandingStyleSheet() + "'" +
            "}";
    }
}
