package com.mycompany.myapp.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Objects;

/**
 * A ServiceProviderUserInfoPermissions.
 */
@Entity
@Table(name = "service_provider_user_info_permissions")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class ServiceProviderUserInfoPermissions implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @Column(name = "allow_org_info_request")
    private Boolean allowOrgInfoRequest;

    @Column(name = "allow_org_user_info_request")
    private Boolean allowOrgUserInfoRequest;

    @Column(name = "allow_auth_less_user_info")
    private Boolean allowAuthLessUserInfo;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Boolean isAllowOrgInfoRequest() {
        return allowOrgInfoRequest;
    }

    public ServiceProviderUserInfoPermissions allowOrgInfoRequest(Boolean allowOrgInfoRequest) {
        this.allowOrgInfoRequest = allowOrgInfoRequest;
        return this;
    }

    public void setAllowOrgInfoRequest(Boolean allowOrgInfoRequest) {
        this.allowOrgInfoRequest = allowOrgInfoRequest;
    }

    public Boolean isAllowOrgUserInfoRequest() {
        return allowOrgUserInfoRequest;
    }

    public ServiceProviderUserInfoPermissions allowOrgUserInfoRequest(Boolean allowOrgUserInfoRequest) {
        this.allowOrgUserInfoRequest = allowOrgUserInfoRequest;
        return this;
    }

    public void setAllowOrgUserInfoRequest(Boolean allowOrgUserInfoRequest) {
        this.allowOrgUserInfoRequest = allowOrgUserInfoRequest;
    }

    public Boolean isAllowAuthLessUserInfo() {
        return allowAuthLessUserInfo;
    }

    public ServiceProviderUserInfoPermissions allowAuthLessUserInfo(Boolean allowAuthLessUserInfo) {
        this.allowAuthLessUserInfo = allowAuthLessUserInfo;
        return this;
    }

    public void setAllowAuthLessUserInfo(Boolean allowAuthLessUserInfo) {
        this.allowAuthLessUserInfo = allowAuthLessUserInfo;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ServiceProviderUserInfoPermissions)) {
            return false;
        }
        return id != null && id.equals(((ServiceProviderUserInfoPermissions) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "ServiceProviderUserInfoPermissions{" +
            "id=" + getId() +
            ", allowOrgInfoRequest='" + isAllowOrgInfoRequest() + "'" +
            ", allowOrgUserInfoRequest='" + isAllowOrgUserInfoRequest() + "'" +
            ", allowAuthLessUserInfo='" + isAllowAuthLessUserInfo() + "'" +
            "}";
    }
}
