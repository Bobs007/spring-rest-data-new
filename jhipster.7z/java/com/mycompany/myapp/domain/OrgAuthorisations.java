package com.mycompany.myapp.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Objects;

import com.mycompany.myapp.domain.enumeration.UserAuthorisationType;

/**
 * A OrgAuthorisations.
 */
@Entity
@Table(name = "org_authorisations")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class OrgAuthorisations implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @Column(name = "parent_org_link_only")
    private Boolean parentOrgLinkOnly;

    @Enumerated(EnumType.STRING)
    @Column(name = "s_s_ouser_access_type")
    private UserAuthorisationType sSOuserAccessType;

    @Column(name = "s_so_user_access_type_message")
    private String sSOUserAccessTypeMessage;

    @Column(name = "s_sso_user_access_attribute")
    private String sSSOUserAccessAttribute;

    @Column(name = "allow_individual_on_orgselect")
    private Boolean allowIndividualOnOrgselect;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Boolean isParentOrgLinkOnly() {
        return parentOrgLinkOnly;
    }

    public OrgAuthorisations parentOrgLinkOnly(Boolean parentOrgLinkOnly) {
        this.parentOrgLinkOnly = parentOrgLinkOnly;
        return this;
    }

    public void setParentOrgLinkOnly(Boolean parentOrgLinkOnly) {
        this.parentOrgLinkOnly = parentOrgLinkOnly;
    }

    public UserAuthorisationType getsSOuserAccessType() {
        return sSOuserAccessType;
    }

    public OrgAuthorisations sSOuserAccessType(UserAuthorisationType sSOuserAccessType) {
        this.sSOuserAccessType = sSOuserAccessType;
        return this;
    }

    public void setsSOuserAccessType(UserAuthorisationType sSOuserAccessType) {
        this.sSOuserAccessType = sSOuserAccessType;
    }

    public String getsSOUserAccessTypeMessage() {
        return sSOUserAccessTypeMessage;
    }

    public OrgAuthorisations sSOUserAccessTypeMessage(String sSOUserAccessTypeMessage) {
        this.sSOUserAccessTypeMessage = sSOUserAccessTypeMessage;
        return this;
    }

    public void setsSOUserAccessTypeMessage(String sSOUserAccessTypeMessage) {
        this.sSOUserAccessTypeMessage = sSOUserAccessTypeMessage;
    }

    public String getsSSOUserAccessAttribute() {
        return sSSOUserAccessAttribute;
    }

    public OrgAuthorisations sSSOUserAccessAttribute(String sSSOUserAccessAttribute) {
        this.sSSOUserAccessAttribute = sSSOUserAccessAttribute;
        return this;
    }

    public void setsSSOUserAccessAttribute(String sSSOUserAccessAttribute) {
        this.sSSOUserAccessAttribute = sSSOUserAccessAttribute;
    }

    public Boolean isAllowIndividualOnOrgselect() {
        return allowIndividualOnOrgselect;
    }

    public OrgAuthorisations allowIndividualOnOrgselect(Boolean allowIndividualOnOrgselect) {
        this.allowIndividualOnOrgselect = allowIndividualOnOrgselect;
        return this;
    }

    public void setAllowIndividualOnOrgselect(Boolean allowIndividualOnOrgselect) {
        this.allowIndividualOnOrgselect = allowIndividualOnOrgselect;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof OrgAuthorisations)) {
            return false;
        }
        return id != null && id.equals(((OrgAuthorisations) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "OrgAuthorisations{" +
            "id=" + getId() +
            ", parentOrgLinkOnly='" + isParentOrgLinkOnly() + "'" +
            ", sSOuserAccessType='" + getsSOuserAccessType() + "'" +
            ", sSOUserAccessTypeMessage='" + getsSOUserAccessTypeMessage() + "'" +
            ", sSSOUserAccessAttribute='" + getsSSOUserAccessAttribute() + "'" +
            ", allowIndividualOnOrgselect='" + isAllowIndividualOnOrgselect() + "'" +
            "}";
    }
}
