package com.mycompany.myapp.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Objects;

/**
 * A AuthorisedOrganisations.
 */
@Entity
@Table(name = "authorised_organisations")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class AuthorisedOrganisations implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @Column(name = "allowonly_authorised")
    private Boolean allowonlyAuthorised;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Boolean isAllowonlyAuthorised() {
        return allowonlyAuthorised;
    }

    public AuthorisedOrganisations allowonlyAuthorised(Boolean allowonlyAuthorised) {
        this.allowonlyAuthorised = allowonlyAuthorised;
        return this;
    }

    public void setAllowonlyAuthorised(Boolean allowonlyAuthorised) {
        this.allowonlyAuthorised = allowonlyAuthorised;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof AuthorisedOrganisations)) {
            return false;
        }
        return id != null && id.equals(((AuthorisedOrganisations) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "AuthorisedOrganisations{" +
            "id=" + getId() +
            ", allowonlyAuthorised='" + isAllowonlyAuthorised() + "'" +
            "}";
    }
}
