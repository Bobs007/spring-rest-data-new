package com.mycompany.myapp.repository;

import com.mycompany.myapp.domain.AuthorisedOrganisations;

import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data  repository for the AuthorisedOrganisations entity.
 */
@SuppressWarnings("unused")
@Repository
public interface AuthorisedOrganisationsRepository extends JpaRepository<AuthorisedOrganisations, Long> {
}
