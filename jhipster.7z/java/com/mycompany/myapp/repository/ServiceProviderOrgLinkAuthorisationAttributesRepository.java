package com.mycompany.myapp.repository;

import com.mycompany.myapp.domain.ServiceProviderOrgLinkAuthorisationAttributes;

import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data  repository for the ServiceProviderOrgLinkAuthorisationAttributes entity.
 */
@SuppressWarnings("unused")
@Repository
public interface ServiceProviderOrgLinkAuthorisationAttributesRepository extends JpaRepository<ServiceProviderOrgLinkAuthorisationAttributes, Long> {
}
