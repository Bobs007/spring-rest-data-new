package com.mycompany.myapp.repository;

import com.mycompany.myapp.domain.ServiceProviderTimeToLiveAttribute;

import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data  repository for the ServiceProviderTimeToLiveAttribute entity.
 */
@SuppressWarnings("unused")
@Repository
public interface ServiceProviderTimeToLiveAttributeRepository extends JpaRepository<ServiceProviderTimeToLiveAttribute, Long> {
}
