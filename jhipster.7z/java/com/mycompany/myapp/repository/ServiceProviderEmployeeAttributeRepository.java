package com.mycompany.myapp.repository;

import com.mycompany.myapp.domain.ServiceProviderEmployeeAttribute;

import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data  repository for the ServiceProviderEmployeeAttribute entity.
 */
@SuppressWarnings("unused")
@Repository
public interface ServiceProviderEmployeeAttributeRepository extends JpaRepository<ServiceProviderEmployeeAttribute, Long> {
}
