package com.mycompany.myapp.repository;

import com.mycompany.myapp.domain.ServiceProviderComments;

import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data  repository for the ServiceProviderComments entity.
 */
@SuppressWarnings("unused")
@Repository
public interface ServiceProviderCommentsRepository extends JpaRepository<ServiceProviderComments, Long> {
}
