package com.mycompany.myapp.repository;

import com.mycompany.myapp.domain.ServiceProviderUserInfoPermissions;

import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data  repository for the ServiceProviderUserInfoPermissions entity.
 */
@SuppressWarnings("unused")
@Repository
public interface ServiceProviderUserInfoPermissionsRepository extends JpaRepository<ServiceProviderUserInfoPermissions, Long> {
}
